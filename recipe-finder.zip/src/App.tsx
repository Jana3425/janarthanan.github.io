import React, { useState, useEffect } from "react";

function App() {
  const [searchTerm, setSearchTerm] = useState("chicken");
  const [recipes, setRecipes] = useState([]);

  useEffect(() => {
    fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${searchTerm}`)
      .then((res) => res.json())
      .then((data) => setRecipes(data.meals || []));
  }, [searchTerm]);

  return (
    <div style={{ padding: "2rem" }}>
      <h1>🍲 Recipe Finder</h1>
      <input
        type="text"
        placeholder="Search recipe..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        style={{ padding: "8px", width: "300px" }}
      />

      <div style={{ display: "flex", flexWrap: "wrap", marginTop: "2rem" }}>
        {recipes.map((recipe) => (
          <div key={recipe.idMeal} style={{ border: "1px solid #ccc", padding: "1rem", width: "250px", margin: "10px" }}>
            <img src={recipe.strMealThumb} alt={recipe.strMeal} style={{ width: "100%" }} />
            <h3>{recipe.strMeal}</h3>
            <p>{recipe.strArea} - {recipe.strCategory}</p>
            <a href={recipe.strSource || "#"} target="_blank" rel="noopener noreferrer">View Recipe</a>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
